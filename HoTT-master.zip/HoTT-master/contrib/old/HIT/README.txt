The files in this directory use the so-called "higher induction types",
which are like inductive types, except that they also prescribe (inductively)
existence of paths. See the following blog posts:

http://homotopytypetheory.org/2011/04/24/higher-inductive-types-a-tour-of-the-menagerie/
http://homotopytypetheory.org/2011/04/25/higher-inductive-types-via-impredicative-polymorphism/

