This directory exists because Coq expects it. At present there are no files
in it, but we may add some from the Coq standard library in the future.
When this happens, please remove this README.txt. It is here only because
git does not want to put empty directories in a repository.

