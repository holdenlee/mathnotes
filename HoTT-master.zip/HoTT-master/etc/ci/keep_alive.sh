#!/usr/bin/env bash

while [ 1 ]
do
    echo ""
    echo "Travis keep-alive spew"
    sleep 5m
done
