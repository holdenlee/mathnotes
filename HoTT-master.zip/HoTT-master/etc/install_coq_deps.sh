#!/usr/bin/env bash

sudo apt-get update -q
sudo apt-get install -q sed grep wget tar ocaml camlp5 liblablgtk2-ocaml-dev liblablgtksourceview2-ocaml-dev
